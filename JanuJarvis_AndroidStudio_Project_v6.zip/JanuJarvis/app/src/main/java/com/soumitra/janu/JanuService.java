package com.soumitra.janu;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Janu's brain: listens for "Hey Janu" (optional), listens to the command, asks the AI,
 * speaks the reply in the chosen voice and performs the actions.
 */
public class JanuService extends Service {

    static final String A_START = "com.soumitra.janu.START";
    static final String A_TALK = "com.soumitra.janu.TALK";
    static final String A_STOP = "com.soumitra.janu.STOP";
    static final String A_SPEAK = "com.soumitra.janu.SPEAK";
    static final String A_REFRESH = "com.soumitra.janu.REFRESH";
    static final String A_HANDSFREE = "com.soumitra.janu.HANDSFREE";

    static final int ST_IDLE = 0, ST_LISTEN = 1, ST_THINK = 2, ST_SPEAK = 3, ST_WAKE = 4, ST_OFF = 5;

    interface UiListener {
        void onState(int state, String status);
        void onText(String who, String text);
        void onLevel(float level);
    }

    static volatile UiListener ui;
    static int lastState = ST_OFF;
    static String lastStatus = "";
    static String lastWho = "", lastText = "";
    /** True after a song started playing: wake-word listening pauses so the mic does not stop the music. */
    static volatile boolean mediaMode = false;
    static boolean running = false;

    private static final int NOTIF_ID = 77;
    private static final String CHANNEL = "janu_service";
    private static final int M_OFF = 0, M_WAKE = 1, M_CMD = 2, M_BUSY = 3;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<String[]> history = new ArrayList<>();
    private final Map<String, Runnable> speechDone = new HashMap<>();
    private final List<Runnable> waitingForTts = new ArrayList<>();
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private boolean ttsReady, foregroundStarted;
    private int mode = M_OFF, gen = 0, uid = 0;
    private ActionRouter router;
    private AudioManager audio;
    private int mutedMask;
    private final WakeEngine engine = new WakeEngine();
    private long lastPrepare;

    private static final Pattern WAKE = Pattern.compile(
        "(?:hey|hi|hello|ok|okay|oye|ओके|हे|हेलो|हैलो)?\\s*(?:janu|jaanu|janoo|jānu|jarvis|जानू|जानु|जनु|जार्विस|जारविस)[\\s,.!?]*(.*)",
        Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.DOTALL);

    // ================================================================= lifecycle

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        mutedMask = Prefs.integer(this, "muted_mask", 0); // undo a mute left behind by a crash
        unmuteBeep();
        router = new ActionRouter(this);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Janu assistant", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { finishSpeech(id, true); }
                    @Override public void onError(String id) { finishSpeech(id, true); }
                    @Override public void onStop(String id, boolean interrupted) { finishSpeech(id, false); }
                });
                applyVoice();
                List<Runnable> q = new ArrayList<>(waitingForTts);
                waitingForTts.clear();
                for (Runnable r : q) r.run();
            }
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? A_START : intent.getAction();
        if (a == null) a = A_START;
        if (!hasMic()) { stopSelf(); return START_NOT_STICKY; }
        if (!foregroundStarted) {
            try {
                Notification n = buildNotification();
                if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
                else startForeground(NOTIF_ID, n);
                foregroundStarted = true;
            } catch (Exception e) { stopSelf(); return START_NOT_STICKY; }
        }
        switch (a) {
            case A_STOP:
                killSr();
                unmuteBeep();
                if (tts != null) tts.stop();
                setState(ST_OFF, t("Janu बंद है", "Janu is off"));
                stopForeground(true);
                stopSelf();
                return START_NOT_STICKY;
            case A_TALK:
                if (tts != null) tts.stop();
                startCommand();
                break;
            case A_HANDSFREE:
                mediaMode = false;
                beginIdle();
                break;
            case A_SPEAK: {
                final String text = intent.getStringExtra("text");
                if (text != null) { killSr(); mode = M_BUSY; speak(text, this::resumeIdle, false); }
                break;
            }
            case A_REFRESH:
                applyVoice();
                if (mode != M_CMD && mode != M_BUSY) beginIdle();
                break;
            default:
                if (mode == M_OFF) beginIdle();
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        killSr();
        unmuteBeep();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        worker.shutdownNow();
        setState(ST_OFF, t("Janu बंद है", "Janu is off"));
        super.onDestroy();
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    // ---- beep killer: system "tung" tones of the recogniser are silenced while it listens ----
    private static final int[] BEEP_STREAMS = {
        AudioManager.STREAM_MUSIC, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM
    };

    private void muteBeep() {
        if (mutedMask != 0) return;
        if (audio == null) audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        int mask = 0;
        for (int i = 0; i < BEEP_STREAMS.length; i++) {
            try {
                if (!audio.isStreamMute(BEEP_STREAMS[i])) {
                    audio.adjustStreamVolume(BEEP_STREAMS[i], AudioManager.ADJUST_MUTE, 0);
                    mask |= 1 << i;
                }
            } catch (Exception ignored) { } // e.g. Do-Not-Disturb policy: just skip that stream
        }
        mutedMask = mask;
        Prefs.put(this, "muted_mask", mask); // so a crash can never leave the phone silent
    }

    private void unmuteBeep() {
        int mask = mutedMask;
        if (mask == 0) return;
        mutedMask = 0;
        Prefs.put(this, "muted_mask", 0);
        if (audio == null) audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        for (int i = 0; i < BEEP_STREAMS.length; i++) {
            if ((mask & (1 << i)) == 0) continue;
            try { audio.adjustStreamVolume(BEEP_STREAMS[i], AudioManager.ADJUST_UNMUTE, 0); }
            catch (Exception ignored) { }
        }
    }

    private String t(String hi, String en) { return Prefs.hindi(this) ? hi : en; }

    private Notification buildNotification() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent talk = PendingIntent.getService(this, 1, new Intent(this, JanuService.class).setAction(A_TALK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 2, new Intent(this, JanuService.class).setAction(A_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Janu")
                .setContentText(t("बोलिए “Hey Janu”", "Say “Hey Janu”"))
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Talk", talk).build())
                .addAction(new Notification.Action.Builder(null, "Stop", stop).build())
                .setOngoing(true)
                .build();
    }

    // ================================================================= state / UI

    private void setState(int st, String status) {
        lastState = st;
        lastStatus = status;
        UiListener l = ui;
        if (l != null) l.onState(st, status);
    }

    private void showText(String who, String text) {
        lastWho = who;
        lastText = text;
        UiListener l = ui;
        if (l != null) l.onText(who, text);
    }

    // ================================================================= listening

    private void beginIdle() {
        if (Prefs.wake(this) && (!mediaMode || WakeEngine.isReady())) {
            if (WakeEngine.isReady()) startEngineWake();
            else { prepareEngine(); listen(false); } // old method keeps working until the offline model is ready
        } else {
            killSr();
            unmuteBeep();
            mode = M_OFF;
            setState(ST_IDLE, mediaMode ? t("गाना चल रहा है • बात करने के लिए ऑर्ब दबाइए", "Playing • tap the orb to talk")
                                        : t("बात करने के लिए ऑर्ब दबाइए", "Tap the orb to talk"));
        }
    }

    private void resumeIdle() { beginIdle(); }

    private void startCommand() { mode = M_BUSY; listen(true); }

    private void killSr() {
        gen++;
        engine.stop();
        if (sr != null) {
            try { sr.cancel(); sr.destroy(); } catch (Exception ignored) { }
            sr = null;
        }
    }

    /** Always-on offline "Hey Janu": one open mic, no recogniser restarts, so no beeps and no flicker. */
    private void startEngineWake() {
        killSr();
        unmuteBeep();
        mode = M_WAKE;
        final int g = gen;
        setState(ST_WAKE, t("बोलिए “Hey Janu”", "Say “Hey Janu”"));
        engine.start(heard -> { if (g == gen && mode == M_WAKE) onWake(""); });
    }

    private void prepareEngine() {
        long now = System.currentTimeMillis();
        if (WakeEngine.isReady() || WakeEngine.isLoading() || now - lastPrepare < 120000) return;
        lastPrepare = now;
        WakeEngine.prepare(getApplicationContext(), new WakeEngine.Progress() {
            @Override public void onStatus(String message, int percent) {
                if (!running || mode != M_WAKE) return;
                setState(ST_WAKE, percent >= 0 ? message + " " + percent + "%" : message);
            }
            @Override public void onFinished(boolean ok) {
                if (!running) return;
                if (ok) {
                    if (mode == M_WAKE && Prefs.wake(JanuService.this)) startEngineWake();
                } else if (mode == M_WAKE) {
                    setState(ST_WAKE, t("ऑफलाइन wake model नहीं मिला (इंटरनेट चेक कीजिए) • पुराना तरीका चालू है",
                                        "Offline wake model unavailable (check internet) • using fallback"));
                }
            }
        });
    }

    private void listen(final boolean command) {
        if (!hasMic()) { unmuteBeep(); mode = M_OFF; setState(ST_IDLE, t("माइक की अनुमति दीजिए", "Please grant microphone permission")); return; }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            unmuteBeep();
            mode = M_OFF; setState(ST_IDLE, t("स्पीच सर्विस नहीं मिली (Google app चाहिए)", "Speech service missing (needs Google app)")); return;
        }
        killSr();
        muteBeep();
        mode = command ? M_CMD : M_WAKE;
        final int g = gen;
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RL(g, command));
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(this));
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        if (command) i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L);
        try {
            sr.startListening(i);
        } catch (Exception e) {
            main.postDelayed(() -> { if (g == gen && !command) listen(false); }, 1000);
            return;
        }
        if (command) setState(ST_LISTEN, t("बोलिए…", "Listening…"));
        else setState(ST_WAKE, t("बोलिए “Hey Janu”", "Say “Hey Janu”"));
    }

    private final class RL implements RecognitionListener {
        private final int g;
        private final boolean command;
        RL(int g, boolean command) { this.g = g; this.command = command; }

        @Override public void onReadyForSpeech(Bundle p) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onBufferReceived(byte[] b) { }
        @Override public void onEvent(int t, Bundle b) { }
        @Override public void onEndOfSpeech() { }

        @Override public void onRmsChanged(float rms) {
            if (g != gen || !command) return;
            UiListener l = ui;
            if (l != null) l.onLevel(Math.max(0f, Math.min(1f, (rms + 2f) / 12f)));
        }

        @Override public void onPartialResults(Bundle b) {
            if (g != gen) return;
            ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            String text = (r == null || r.isEmpty()) ? "" : r.get(0);
            if (command) { if (!text.isEmpty()) showText(t("आप", "You"), text); return; }
            String c = extractCommand(text);
            if (c != null && c.isEmpty()) onWake(""); // only "Hey Janu" so far -> start listening right away
        }

        @Override public void onResults(Bundle b) {
            if (g != gen) return;
            ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            String text = (r == null || r.isEmpty()) ? "" : r.get(0).trim();
            if (command) {
                if (text.isEmpty()) { setState(ST_IDLE, t("सुनाई नहीं दिया बाबू", "I didn't catch that, Babu")); main.postDelayed(JanuService.this::resumeIdle, 900); }
                else process(text);
            } else {
                String c = extractCommand(text);
                if (c == null) listen(false); else onWake(c);
            }
        }

        @Override public void onError(int error) {
            if (g != gen) return;
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                unmuteBeep(); mode = M_OFF; setState(ST_IDLE, t("माइक की अनुमति दीजिए", "Please grant microphone permission")); return;
            }
            if (command) {
                boolean quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT;
                setState(ST_IDLE, quiet ? t("सुनाई नहीं दिया", "I didn't catch that")
                                        : t("स्पीच एरर, इंटरनेट चेक कीजिए", "Speech error, check your internet"));
                main.postDelayed(JanuService.this::resumeIdle, 1000);
            } else {
                long delay = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200
                        : (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_SERVER) ? 1500 : 300;
                final int cg = g;
                main.postDelayed(() -> { if (cg == gen && Prefs.wake(JanuService.this) && !mediaMode) listen(false); }, delay);
            }
        }
    }

    /** null = no wake word; "" = only the wake word; otherwise the command that followed it. */
    private static String extractCommand(String text) {
        if (text == null || text.isEmpty()) return null;
        Matcher m = WAKE.matcher(text.trim());
        if (!m.find()) return null;
        String rest = m.group(1);
        return rest == null ? "" : rest.trim();
    }

    private void onWake(String cmd) {
        killSr();
        mode = M_BUSY;
        if (cmd.isEmpty()) speak(t("जी बाबू, बोलिए", "Yes Babu, I'm listening"), () -> listen(true), false);
        else process(cmd);
    }

    // ================================================================= thinking + acting

    private void process(final String text) {
        killSr();
        unmuteBeep();
        mode = M_BUSY;
        showText(t("आप", "You"), text);
        setState(ST_THINK, t("सोच रहा हूँ…", "Thinking…"));
        final VoiceProfile vp = VoiceProfile.ALL[Prefs.voice(this)];
        final List<String[]> snap = new ArrayList<>(history);
        worker.execute(() -> {
            String json = null, err = null;
            try {
                json = router.tryLocal(text, vp);
                if (json == null) json = AiClient.ask(this, AiClient.system(this, vp), snap, text);
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fj = json, fe = err;
            main.post(() -> handleResult(text, fj, fe));
        });
    }

    private void handleResult(String userText, String json, String err) {
        if (json == null) {
            String say = "NO_KEY".equals(err)
                    ? t("पहले सेटिंग्स में अपनी Gemini API की डालिए", "Please add your Gemini API key in Settings first")
                    : t("API या इंटरनेट में दिक्कत है", "There is a network or API problem");
            showText("Janu", say + ("NO_KEY".equals(err) || err == null ? "" : "\n(" + err + ")"));
            speak(say, this::resumeIdle, false);
            return;
        }
        String reply = "";
        JSONArray acts = null;
        try {
            String clean = json.trim();
            int s = clean.indexOf('{'), e = clean.lastIndexOf('}');
            JSONObject o = new JSONObject(s >= 0 && e > s ? clean.substring(s, e + 1) : clean);
            reply = o.optString("reply", "").trim();
            acts = o.optJSONArray("actions");
        } catch (Exception ex) {
            reply = json.trim(); // model answered in plain text
        }
        history.add(new String[]{"user", userText});
        history.add(new String[]{"model", json});
        while (history.size() > 12) history.remove(0);

        final boolean hasActs = acts != null && acts.length() > 0;
        final int n = (reply.isEmpty() ? 0 : 1) + (hasActs ? 1 : 0);
        if (n == 0) { resumeIdle(); return; }
        final AtomicInteger left = new AtomicInteger(n);
        final Runnable done = () -> { if (left.decrementAndGet() <= 0) resumeIdle(); };

        if (!reply.isEmpty()) speak(reply, done, false);
        if (hasActs) {
            final JSONArray fa = acts;
            if (reply.isEmpty()) setState(ST_THINK, t("काम कर रहा हूँ…", "Working on it…"));
            worker.execute(() -> {
                String ae;
                try { ae = router.run(fa); } catch (Exception ex) { ae = t("काम पूरा नहीं हो पाया", "I couldn't finish that"); }
                final String fae = ae;
                main.post(() -> {
                    if (fae != null) { showText("Janu", fae); left.incrementAndGet(); speak(fae, done, true); }
                    done.run();
                });
            });
        }
    }

    // ================================================================= speaking

    private void speak(final String text, final Runnable done, final boolean add) {
        unmuteBeep();
        showText("Janu", text);
        setState(ST_SPEAK, t("बोल रहा हूँ…", "Speaking…"));
        if (!ttsReady) {
            waitingForTts.add(() -> speak(text, done, add));
            return;
        }
        String id = "u" + (++uid);
        if (done != null) speechDone.put(id, done);
        Bundle p = new Bundle();
        p.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0.9f);
        int r = tts.speak(text, add ? TextToSpeech.QUEUE_ADD : TextToSpeech.QUEUE_FLUSH, p, id);
        if (r != TextToSpeech.SUCCESS) finishSpeech(id, true);
    }

    private void finishSpeech(final String id, final boolean run) {
        main.post(() -> {
            Runnable r = speechDone.remove(id);
            if (run && r != null) r.run();
        });
    }

    private void applyVoice() {
        if (tts == null || !ttsReady) return;
        VoiceProfile vp = VoiceProfile.ALL[Prefs.voice(this)];
        Locale loc = Prefs.hindi(this) ? new Locale("hi", "IN") : new Locale("en", "IN");
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US);
        tts.setPitch(vp.pitch);
        tts.setSpeechRate(vp.rate);
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) return;
            final String lang = tts.getLanguage() == null ? loc.getLanguage() : tts.getLanguage().getLanguage();
            List<Voice> list = new ArrayList<>();
            for (Voice v : all) if (v.getLocale().getLanguage().equals(lang) && !v.getFeatures().contains("notInstalled")) list.add(v);
            if (list.isEmpty()) return;
            Collections.sort(list, new Comparator<Voice>() {
                @Override public int compare(Voice a, Voice b) { return a.getName().compareTo(b.getName()); }
            });
            Voice pick = null;
            if (vp.male) {
                for (Voice v : list) if (v.getName().contains("-hic-") || v.getName().contains("-hid-")) { pick = v; break; }
                if (pick == null) pick = list.get(list.size() - 1);
            } else {
                pick = list.get(vp.slot % list.size());
            }
            tts.setVoice(pick);
        } catch (Exception ignored) { }
    }
}
