# Janu — Voice Assistant for Android

A Jarvis-style, always-listening voice assistant with a warm, caring "girlfriend" personality.
Say **"Hey Janu"** and she answers, talks back in a soft voice and controls your phone.

Package `com.soumitra.janu` · minSdk 26 · targetSdk 35 · version 3.0 · Developed by Soumitra

## Highlights
- **Always-on, offline "Hey Janu"** (Vosk). The microphone stays open like Siri: no recogniser restarts,
  no "tung-tung" beep, no flickering mic icon. Audio never leaves the phone for wake-word detection.
- **Glowing AI orb** that animates while listening / thinking / speaking and takes the colour of the selected voice.
- **5 voices** (Settings → *Janu की आवाज़*): Pyari Didi, Anime Girl, Jarvis Lady, Sweet Heart, Girlfriend.
  Picking one recolours the orb and Janu introduces herself in that voice.
- **Personality**: loving, emotional and caring — calls you *Babu / Sona / Boss*, comforts you when you are low.
- **Gemini API** (free key, with a backup key) plus any OpenAI-compatible API as a fallback.
- **Phone control** through Accessibility: YouTube auto-play, WhatsApp messages, Instagram / Facebook search,
  comment, like, scroll, call, SMS, back / home.

## Build
**Android Studio:** open the `JanuJarvis` folder (JDK 17) → Gradle sync → *Build ▸ Build APK(s)*.

**GitHub Actions (phone friendly):** upload this ZIP to a repository together with
`.github/workflows/build-apk.yml`; the workflow unzips it and publishes the APK as the `Janu-APK` artifact.

## First run
1. Open the app, allow Microphone / Contacts / Phone / Notifications.
2. **Stay online for the first launch**: Janu downloads a ~40 MB offline wake-word model once
   (status shows a percentage). After that, "Hey Janu" works without internet. Until it finishes, the
   old Google recogniser is used as a fallback.
3. Settings → paste your Gemini key (free: aistudio.google.com/apikey) → **Verify**.
4. Settings → turn ON Accessibility and *Display over other apps*; set Battery to *Unrestricted*.
   On Android 13+ sideloaded apps also need: App info ▸ ⋮ ▸ *Allow restricted settings*.
5. Settings → pick your favourite voice.

## Example commands
- "Hey Janu, Honey Singh ka gana play karo"
- "Golu ko WhatsApp pe message karo ki kal milte hain"
- "Facebook mein Golu ko search karo" · "Is video pe comment karo bahut badhiya" · "Next reel"

## Notes & limits
- The green microphone dot in the status bar is Android's privacy indicator for any app holding the mic;
  it cannot be hidden, but it now stays steady instead of blinking.
- Command listening after the wake word still uses Google's recogniser (internet needed); its start/stop
  tones are muted automatically and the volume is restored right after.
- App control depends on the target app's screen layout and may need updates when those apps change.
- Voices come from the phone's Google Text-to-Speech engine; install a Hindi voice pack for the best result.
- Do not tell Janu passwords or OTPs; Gemini free-tier data may be used by Google to improve its products.
