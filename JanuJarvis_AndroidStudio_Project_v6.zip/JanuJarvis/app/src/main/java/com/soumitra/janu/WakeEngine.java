package com.soumitra.janu;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;
import org.vosk.LibVosk;
import org.vosk.LogLevel;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.regex.Pattern;

/**
 * Offline "Hey Janu" detector (Vosk).
 *
 * It keeps ONE AudioRecord open and feeds it to an on-device recogniser, so there is no
 * SpeechRecognizer start/stop => no "tung tung" beep and no flickering mic icon (works like Siri).
 * The small Hindi model (~40 MB) is downloaded once, the first time Janu runs.
 */
final class WakeEngine {

    interface Listener { void onWake(String heard); }

    interface Progress {
        /** Called on the main thread. percent < 0 = no number available. */
        void onStatus(String message, int percent);
        void onFinished(boolean ok);
    }

    private static final String MODEL_NAME = "vosk-model-small-hi-0.22";
    private static final String MODEL_URL = "https://alphacephei.com/vosk/models/" + MODEL_NAME + ".zip";
    private static final int RATE = 16000;

    /** Wake words as the Hindi model writes them (plus Latin spellings, just in case). */
    private static final Pattern HIT = Pattern.compile(
        "(?<![\\p{L}\\p{M}])(?:जानू|जानु|जनू|जनु|जानूं|जार्विस|जारविस|जार्वीस|janu|jaanu|janoo|jarvis)",
        Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile Model model;
    private static Recognizer recognizer; // only touched by the single listening thread
    private static volatile boolean loading;
    private static volatile String lastError = "";

    private volatile boolean running;
    private Thread thread;

    // ------------------------------------------------------------------ state

    static boolean isReady() { return model != null && recognizer != null; }
    static boolean isLoading() { return loading; }
    static String lastError() { return lastError; }

    // ------------------------------------------------------------------ model download + load

    static void prepare(final Context app, final Progress progress) {
        if (isReady() || loading) return;
        loading = true;
        new Thread(() -> {
            boolean ok = false;
            try {
                LibVosk.setLogLevel(LogLevel.WARNINGS);
                File root = new File(app.getFilesDir(), "vosk");
                File dir = new File(root, MODEL_NAME);
                File flag = new File(root, MODEL_NAME + ".ok");
                if (!flag.exists()) {
                    deleteRecursive(dir);
                    root.mkdirs();
                    download(app, root, progress);
                    if (!flag.createNewFile() && !flag.exists()) throw new Exception("flag");
                }
                post(progress, "Janu तैयार हो रही है…", -1);
                Model m = new Model(dir.getAbsolutePath());
                Recognizer r = new Recognizer(m, (float) RATE);
                recognizer = r;
                model = m;
                ok = true;
                lastError = "";
            } catch (Throwable e) {
                lastError = String.valueOf(e.getMessage());
            }
            loading = false;
            final boolean fok = ok;
            MAIN.post(() -> progress.onFinished(fok));
        }, "janu-wake-prepare").start();
    }

    private static void post(final Progress p, final String msg, final int pct) {
        MAIN.post(() -> p.onStatus(msg, pct));
    }

    private static void download(Context app, File root, Progress progress) throws Exception {
        File zip = new File(app.getCacheDir(), MODEL_NAME + ".zip");
        HttpURLConnection c = null;
        try {
            String url = MODEL_URL;
            for (int hop = 0; hop < 5; hop++) {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setInstanceFollowRedirects(false);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (loc == null) throw new Exception("redirect");
                    url = loc;
                    continue;
                }
                if (code != 200) throw new Exception("HTTP " + code);
                break;
            }
            long total = c.getContentLengthLong();
            try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(zip)) {
                byte[] buf = new byte[32 * 1024];
                long done = 0;
                int lastPct = -1, n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    done += n;
                    if (total > 0) {
                        int pct = (int) (done * 100 / total);
                        if (pct != lastPct) { lastPct = pct; post(progress, "Wake model डाउनलोड हो रहा है (एक बार)…", pct); }
                    }
                }
            }
        } finally {
            if (c != null) c.disconnect();
        }
        post(progress, "Wake model खोल रहे हैं…", -1);
        String base = root.getCanonicalPath() + File.separator;
        try (ZipInputStream zin = new ZipInputStream(new java.io.BufferedInputStream(new java.io.FileInputStream(zip)))) {
            ZipEntry e;
            byte[] buf = new byte[32 * 1024];
            while ((e = zin.getNextEntry()) != null) {
                File f = new File(root, e.getName());
                if (!f.getCanonicalPath().startsWith(base)) continue; // zip-slip guard
                if (e.isDirectory()) { f.mkdirs(); continue; }
                File parent = f.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream out = new FileOutputStream(f)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) out.write(buf, 0, n);
                }
            }
        }
        //noinspection ResultOfMethodCallIgnored
        zip.delete();
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    // ------------------------------------------------------------------ listening

    /** Starts listening on a background thread. Safe to call only when isReady(). */
    synchronized void start(final Listener l) {
        if (running || !isReady()) return;
        Thread old = thread;
        if (old != null) { try { old.join(1500); } catch (InterruptedException ignored) { } }
        running = true;
        thread = new Thread(() -> loop(l), "janu-wake");
        thread.start();
    }

    /** Stops listening and fully releases the microphone before returning. */
    synchronized void stop() {
        running = false;
        Thread t = thread;
        thread = null;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(1500); } catch (InterruptedException ignored) { }
        }
    }

    private void loop(final Listener l) {
        AudioRecord rec = null;
        try {
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int size = Math.max(min, RATE); // >= 0.5 s of audio
            rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) return;
            final Recognizer r = recognizer;
            r.reset();
            rec.startRecording();
            short[] buf = new short[2048];
            while (running) {
                int n = rec.read(buf, 0, buf.length);
                if (n <= 0) { if (n < 0) break; continue; }
                String text;
                if (r.acceptWaveForm(buf, n)) text = field(r.getResult(), "text");
                else text = field(r.getPartialResult(), "partial");
                if (text.isEmpty()) continue;
                if (HIT.matcher(text).find()) {
                    running = false;
                    r.reset();
                    final String heard = text;
                    MAIN.post(() -> l.onWake(heard));
                    break;
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (Throwable ignored) { }
                try { rec.release(); } catch (Throwable ignored) { }
            }
            running = false;
        }
    }

    private static String field(String json, String key) {
        try { return new JSONObject(json).optString(key, "").trim(); }
        catch (Throwable e) { return ""; }
    }
}
