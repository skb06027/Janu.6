package com.soumitra.janu;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Turns Gemini's action list (or a fast local rule) into real phone actions. */
final class ActionRouter {
    private static final String YT = "com.google.android.youtube";

    private final Context ctx;

    ActionRouter(Context c) { ctx = c.getApplicationContext(); }

    // ================================================================= local fast path

    private static final Set<String> STOP = new HashSet<>(Arrays.asList(
        "play", "karo", "kar", "do", "de", "dena", "ka", "ki", "ke", "ko", "gana", "gaana", "song", "songs",
        "video", "youtube", "yt", "pe", "par", "me", "mein", "mai", "se", "chalao", "chala", "bajao", "baja",
        "laga", "lagao", "sunao", "suna", "please", "plz", "janu", "jarvis", "hey", "ok", "okay", "ek", "mera",
        "mere", "wala", "wali", "music", "on", "the", "a", "my", "to",
        "प्ले", "करो", "कर", "दो", "दे", "का", "की", "के", "को", "गाना", "गाने", "सॉन्ग", "वीडियो", "यूट्यूब",
        "पे", "पर", "में", "से", "चलाओ", "चला", "बजाओ", "बजा", "लगाओ", "लगा", "सुनाओ", "सुना", "जानू",
        "जार्विस", "प्लीज", "एक", "मेरा", "मेरे", "वाला", "वाली", "म्यूजिक", "हे", "ओके"));

    private static final String[] BLOCK = {"message", "msg", "मैसेज", "comment", "कमेंट", "whatsapp", "व्हाट्सएप",
        "call", "कॉल", "search", "सर्च", "facebook", "फेसबुक", "instagram", "इंस्टाग्राम", "insta"};

    private static boolean hasAny(String t, String... words) {
        for (String w : words) if (t.contains(w)) return true;
        return false;
    }

    /** Returns a ready JSON answer for the most common commands (no network = instant), or null. */
    String tryLocal(String raw, VoiceProfile vp) {
        boolean hi = Prefs.hindi(ctx);
        String t = raw.toLowerCase(Locale.ROOT).replaceAll("[\\p{Punct}।]", " ").replaceAll("\\s+", " ").trim();
        if (t.isEmpty() || hasAny(t, BLOCK)) return null;
        try {
            boolean play = hasAny(t, "play", "चला", "बजा", "bajao", "chalao", "chala", "laga", "sunao", "सुना", "लगा");
            boolean song = hasAny(t, "gana", "gaana", "गाना", "गाने", "song", "video", "वीडियो", "youtube", "यूट्यूब", "music", "म्यूजिक");
            if (play && song) {
                String q = strip(t);
                if (q.length() > 1) {
                    if (hasAny(t, "gana", "gaana", "गाना", "गाने") && !q.contains("song") && !q.contains("सॉन्ग")) q += " song";
                    String reply = hi ? "ठीक है बाबू, " + q + " अभी चला रही हूँ"
                                      : "Okay Babu, playing " + q + " for you.";
                    return new JSONObject().put("reply", reply).put("actions", new JSONArray()
                            .put(new JSONObject().put("type", "youtube_play").put("query", q))).toString();
                }
            }
            boolean open = hasAny(t, "open", "khol", "खोल");
            if (open && t.split(" ").length <= 5) {
                String name = t.replaceAll("\\b(open|karo|kar|do|please|plz|janu|jarvis|hey|ok|okay|app|ko|ka)\\b", " ")
                        .replace("kholo", " ").replace("khol", " ").replace("खोलो", " ").replace("खोल", " ")
                        .replace("दो", " ").replace("करो", " ").replace("जानू", " ").replaceAll("\\s+", " ").trim();
                if (!name.isEmpty() && findPackage(name) != null || isSpecialApp(name)) {
                    String reply = hi ? "जी सोना, " + name + " अभी खोल रही हूँ"
                                      : "Sure Sona, opening " + name + " for you.";
                    return new JSONObject().put("reply", reply).put("actions", new JSONArray()
                            .put(new JSONObject().put("type", "open_app").put("app", name))).toString();
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static String strip(String t) {
        StringBuilder sb = new StringBuilder();
        for (String w : t.split(" ")) if (!STOP.contains(w)) sb.append(w).append(' ');
        return sb.toString().trim();
    }

    // ================================================================= executing actions

    /** Runs actions in order on the calling (background) thread. Returns an error sentence to speak, or null. */
    String run(JSONArray acts) throws InterruptedException {
        for (int i = 0; i < acts.length(); i++) {
            JSONObject a = acts.optJSONObject(i);
            if (a == null) continue;
            String err = one(a);
            if (err != null) return err;
        }
        return null;
    }

    private String msg(String hi, String en) { return Prefs.hindi(ctx) ? hi : en; }

    private String needAcc() {
        return msg("पहले सेटिंग्स में एक्सेसिबिलिटी चालू कीजिए", "Please enable Accessibility in settings first");
    }

    private String one(JSONObject a) throws InterruptedException {
        String type = a.optString("type").toLowerCase(Locale.ROOT);
        JanuAccessibilityService acc = JanuAccessibilityService.get();
        switch (type) {
            case "open_app": {
                String app = a.optString("app");
                if (!launchApp(app)) return msg("यह ऐप नहीं मिला: " + app, "I couldn't find the app " + app);
                Thread.sleep(700);
                return null;
            }
            case "youtube_play":
            case "youtube_search": {
                String q = a.optString("query");
                openYoutubeSearch(q);
                if (type.equals("youtube_search")) return null;
                if (acc == null) return needAcc();
                Thread.sleep(1500);
                boolean ok = acc.waitClick(11000, "play video", "वीडियो चलाएं", "views", "व्यू");
                if (!ok) return msg("गाना अपने आप नहीं चला, रिज़ल्ट में खुद चुन लीजिए", "I couldn't auto-play it, please pick a result");
                JanuService.mediaMode = true;
                return null;
            }
            case "search_in_app": return searchInApp(a.optString("app"), a.optString("query"), acc);
            case "whatsapp_message": return whatsapp(a.optString("contact"), a.optString("text"), acc);
            case "send_sms": {
                String phone = resolvePhone(a.optString("contact"));
                if (phone == null) return msg("कॉन्टैक्ट नहीं मिला", "I couldn't find that contact");
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone));
                i.putExtra("sms_body", a.optString("text"));
                start(i);
                if (acc == null) return needAcc();
                Thread.sleep(1200);
                if (!acc.waitClick(7000, "Send", "भेजें", "Send SMS")) return msg("मैसेज भेज नहीं पाया", "I couldn't press send");
                return null;
            }
            case "call": {
                String phone = resolvePhone(a.optString("contact"));
                if (phone == null) return msg("कॉन्टैक्ट नहीं मिला", "I couldn't find that contact");
                boolean can = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
                start(new Intent(can ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
                return null;
            }
            case "comment": {
                if (acc == null) return needAcc();
                String text = a.optString("text");
                acc.waitClick(3500, "Comment", "Comments", "Add a comment", "कमेंट");
                Thread.sleep(900);
                if (!acc.waitSetText(2500, text)) {
                    acc.clickLabel("Add a comment", "Add comment", "Write a comment", "Comment as");
                    Thread.sleep(700);
                    if (!acc.waitSetText(3500, text)) return msg("कमेंट बॉक्स नहीं मिला", "I couldn't find the comment box");
                }
                Thread.sleep(500);
                if (!acc.waitClick(3500, "Post", "Send", "Reply", "पोस्ट", "भेजें")) return msg("कमेंट पोस्ट नहीं हो पाया", "I couldn't post the comment");
                return null;
            }
            case "like": {
                if (acc == null) return needAcc();
                if (!acc.waitClick(3000, "like this video", "Like", "Love", "लाइक")) return msg("लाइक बटन नहीं मिला", "I couldn't find the like button");
                return null;
            }
            case "scroll": {
                if (acc == null) return needAcc();
                boolean down = !a.optString("direction", "down").equalsIgnoreCase("up");
                if (down) acc.swipe(0.5f, 0.75f, 0.5f, 0.25f, 260); else acc.swipe(0.5f, 0.25f, 0.5f, 0.75f, 260);
                Thread.sleep(500);
                return null;
            }
            case "click": {
                if (acc == null) return needAcc();
                if (!acc.waitClick(4000, a.optString("label"))) return msg("स्क्रीन पर वह बटन नहीं मिला", "I couldn't find that on screen");
                return null;
            }
            case "type_text": {
                if (acc == null) return needAcc();
                if (!acc.waitSetText(3000, a.optString("text"))) return msg("टाइप करने की जगह नहीं मिली", "I couldn't find a text box");
                return null;
            }
            case "back": if (acc == null) return needAcc(); acc.back(); Thread.sleep(300); return null;
            case "home": if (acc == null) return needAcc(); acc.home(); Thread.sleep(300); return null;
            case "recents": if (acc == null) return needAcc(); acc.recents(); Thread.sleep(300); return null;
            case "web_search":
                start(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))));
                return null;
            case "open_url":
                start(new Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))));
                return null;
            case "wait":
                Thread.sleep((long) (Math.max(0, Math.min(10, a.optDouble("seconds", 1))) * 1000));
                return null;
            default:
                return null;
        }
    }

    // ----------------------------------------------------------------- specific flows

    private void openYoutubeSearch(String q) {
        Intent i = new Intent(Intent.ACTION_SEARCH).setPackage(YT).putExtra("query", q);
        try {
            if (ctx.getPackageManager().getLaunchIntentForPackage(YT) == null) throw new ActivityNotFoundException();
            start(i);
        } catch (ActivityNotFoundException e) {
            start(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))));
        }
    }

    private String searchInApp(String app, String q, JanuAccessibilityService acc) throws InterruptedException {
        if (app.toLowerCase(Locale.ROOT).contains("youtube")) { openYoutubeSearch(q); return null; }
        if (acc == null) return needAcc();
        String pkg = findPackage(app);
        if (pkg == null || !launchApp(app)) return msg("यह ऐप नहीं मिला: " + app, "I couldn't find the app " + app);
        acc.waitForPackage(pkg, 7000);
        Thread.sleep(1500);
        acc.waitClick(4500, "Search and explore", "Search Facebook", "Search", "खोजें", "सर्च");
        Thread.sleep(700);
        if (!acc.waitSetText(1800, q)) {
            acc.clickLabel("Search", "सर्च");
            Thread.sleep(800);
            if (!acc.waitSetText(3500, q)) return msg("सर्च बॉक्स नहीं मिला", "I couldn't find the search box");
        }
        Thread.sleep(600);
        if (!acc.pressEnter()) acc.waitClick(2500, q);
        return null;
    }

    private String whatsapp(String contact, String text, JanuAccessibilityService acc) throws InterruptedException {
        String pkg = installed("com.whatsapp") ? "com.whatsapp" : installed("com.whatsapp.w4b") ? "com.whatsapp.w4b" : null;
        if (pkg == null) return msg("व्हाट्सएप इंस्टॉल नहीं है", "WhatsApp is not installed");
        if (acc == null) return needAcc();
        String phone = resolvePhone(contact);
        if (phone != null) {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + phone + "?text=" + Uri.encode(text)));
            i.setPackage(pkg);
            start(i);
            Thread.sleep(1600);
            if (!acc.waitClick(9000, "Send", "भेजें")) return msg("मैसेज भेज नहीं पाया", "I couldn't press send");
            return null;
        }
        // Contact not in phone book: search inside WhatsApp.
        launchPackage(pkg);
        acc.waitForPackage(pkg, 7000);
        Thread.sleep(1500);
        if (!acc.waitClick(4500, "Search", "खोजें")) return msg("व्हाट्सएप में सर्च नहीं मिला", "I couldn't find WhatsApp search");
        Thread.sleep(600);
        if (!acc.waitSetText(3500, contact)) return msg("सर्च बॉक्स नहीं मिला", "I couldn't find the search box");
        Thread.sleep(1400);
        if (!acc.waitClick(4500, contact)) return msg("कॉन्टैक्ट नहीं मिला: " + contact, "I couldn't find " + contact + " in WhatsApp");
        Thread.sleep(1200);
        if (!acc.waitSetText(5000, text)) return msg("मैसेज बॉक्स नहीं मिला", "I couldn't find the message box");
        Thread.sleep(400);
        if (!acc.waitClick(3500, "Send", "भेजें")) return msg("मैसेज भेज नहीं पाया", "I couldn't press send");
        return null;
    }

    // ----------------------------------------------------------------- apps

    private static final Map<String, String> APPS = new HashMap<>();
    static {
        String[][] m = {
            {"youtube", YT}, {"you tube", YT}, {"यूट्यूब", YT}, {"yt", YT},
            {"whatsapp", "com.whatsapp"}, {"whats app", "com.whatsapp"}, {"व्हाट्सएप", "com.whatsapp"}, {"वाट्सएप", "com.whatsapp"},
            {"facebook", "com.facebook.katana"}, {"fb", "com.facebook.katana"}, {"फेसबुक", "com.facebook.katana"},
            {"instagram", "com.instagram.android"}, {"insta", "com.instagram.android"}, {"इंस्टाग्राम", "com.instagram.android"},
            {"chrome", "com.android.chrome"}, {"क्रोम", "com.android.chrome"},
            {"maps", "com.google.android.apps.maps"}, {"google maps", "com.google.android.apps.maps"}, {"मैप्स", "com.google.android.apps.maps"},
            {"gmail", "com.google.android.gm"}, {"telegram", "org.telegram.messenger"}, {"टेलीग्राम", "org.telegram.messenger"},
            {"spotify", "com.spotify.music"}, {"snapchat", "com.snapchat.android"}, {"twitter", "com.twitter.android"},
            {"x", "com.twitter.android"}, {"play store", "com.android.vending"}, {"playstore", "com.android.vending"},
            {"photos", "com.google.android.apps.photos"}, {"gallery", "com.google.android.apps.photos"},
        };
        for (String[] e : m) APPS.put(e[0], e[1]);
    }

    private boolean isSpecialApp(String n) {
        n = n.toLowerCase(Locale.ROOT);
        return n.equals("settings") || n.equals("सेटिंग्स") || n.equals("camera") || n.equals("कैमरा")
                || n.equals("phone") || n.equals("dialer") || n.equals("फोन");
    }

    private boolean installed(String pkg) { return ctx.getPackageManager().getLaunchIntentForPackage(pkg) != null; }

    String findPackage(String name) {
        String n = name.toLowerCase(Locale.ROOT).trim();
        String pkg = APPS.get(n);
        if (pkg != null && installed(pkg)) return pkg;
        PackageManager pm = ctx.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
        String best = null; int bestLen = Integer.MAX_VALUE;
        for (ResolveInfo ri : list) {
            String label = String.valueOf(ri.loadLabel(pm)).toLowerCase(Locale.ROOT);
            if (label.equals(n)) return ri.activityInfo.packageName;
            if (!n.isEmpty() && label.contains(n) && label.length() < bestLen) { best = ri.activityInfo.packageName; bestLen = label.length(); }
        }
        return best;
    }

    private void launchPackage(String pkg) {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) start(i);
    }

    boolean launchApp(String name) {
        String n = name.toLowerCase(Locale.ROOT).trim();
        if (n.equals("settings") || n.equals("सेटिंग्स")) { start(new Intent(Settings.ACTION_SETTINGS)); return true; }
        if (n.equals("camera") || n.equals("कैमरा")) { start(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return true; }
        if (n.equals("phone") || n.equals("dialer") || n.equals("फोन")) { start(new Intent(Intent.ACTION_DIAL)); return true; }
        String pkg = findPackage(name);
        if (pkg == null) return false;
        launchPackage(pkg);
        return true;
    }

    /** Starts an activity from the accessibility service context when possible (best background-launch rights). */
    private void start(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        JanuAccessibilityService acc = JanuAccessibilityService.get();
        try {
            (acc != null ? (Context) acc : ctx).startActivity(i);
        } catch (Exception e) {
            try { ctx.startActivity(i); } catch (Exception ignored) { }
        }
    }

    // ----------------------------------------------------------------- contacts

    /** Contact name or number -> digits ready for wa.me / tel. Null if unknown. */
    private String resolvePhone(String contact) {
        if (contact == null) return null;
        String digitsOnly = contact.replaceAll("[^0-9+]", "");
        if (digitsOnly.replace("+", "").length() >= 8 && contact.replaceAll("[0-9+\\s-]", "").isEmpty()) return normalize(digitsOnly);
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null;
        String number = null; int bestLen = Integer.MAX_VALUE;
        try (Cursor c = ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", new String[]{"%" + contact.trim() + "%"}, null)) {
            while (c != null && c.moveToNext()) {
                String name = c.getString(0) == null ? "" : c.getString(0);
                if (name.equalsIgnoreCase(contact.trim())) return normalize(c.getString(1));
                if (name.length() < bestLen) { bestLen = name.length(); number = c.getString(1); }
            }
        } catch (Exception ignored) { }
        return number == null ? null : normalize(number);
    }

    /** Assumes India (+91) for plain 10-digit numbers. */
    private static String normalize(String raw) {
        if (raw == null) return null;
        String d = raw.replaceAll("[^0-9]", "");
        if (d.length() == 10) return "91" + d;
        if (d.length() == 11 && d.startsWith("0")) return "91" + d.substring(1);
        return d;
    }
}
